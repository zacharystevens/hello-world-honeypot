"""
AWS Lambda handler for the refactored honeypot system.
This file provides backward compatibility with the original handler name.
"""

from src.lambda_handler import lambda_handler as honeypot_lambda_handler

# Main handler function (backward compatible)
def lambda_handler(event, context):
    """Main Lambda handler - delegates to the modular implementation."""
    return honeypot_lambda_handler(event, context)

# Alternative handler names for compatibility
honeypot_lambda = lambda_handler
